# LTT Consulting — Intro web (integrable)

## Qué hay aquí
- **`LTT Consulting - Intro.html`** — la animación lista para integrar, sin controles de demo. Todo con prefijo `.ltt-*` y una función global `lttIntroPlay()`.
- **`logos/ltt-consulting-negativo.svg`** — logotipo vectorial final (fuentes incrustadas, no depende de fuentes externas).
- **`logos/ltt-consulting-negativo.png`** — mismo logo a 4000×1300px.

## Integración rápida
1. Copia el bloque `<style>` (reglas `.ltt-*`) y el markup `.ltt-stage` a tu página o componente.
2. Carga las fuentes (Google Fonts): **Space Grotesk 600** e **IBM Plex Mono 500**.
3. La animación arranca sola en `document.fonts.ready`. Para lanzarla tú mismo (p. ej. al entrar en la sección de Consultoría), llama a `lttIntroPlay()`.

## Elegir el final
Cambia la clase del `.ltt-lockup`:
- `ltt-fade` — Fundido (por defecto)
- `ltt-wipe` — Cortina (barrido izq→der)
- `ltt-rise` — Ascenso (sube desde máscara)

## Secuencia
1. Aparece **LATRASTIENDA** completa.
2. Colapso horizontal → quedan las iniciales **LTT** (letras `data-keep`: posiciones 1, 3 y 7).
3. Crece la barra divisoria (Trigo `#C9A227`) — **LTT no se desplaza** (la cola va absoluta).
4. Entra **Consulting** según el final elegido + barrido de luz que sale por la derecha.

## Notas
- Respeta `prefers-reduced-motion: reduce` (salta al estado final sin animar).
- Colores: Tinta `#1A1714` · Papel `#F4EFE6` · Trigo `#C9A227`.
- Orquestado con `setTimeout` (no rAF) para que no se congele en iframes/segundo plano.
- Clave técnica: cada letra necesita `min-width: 0` + `overflow: hidden` para poder colapsar su `width` a 0.
